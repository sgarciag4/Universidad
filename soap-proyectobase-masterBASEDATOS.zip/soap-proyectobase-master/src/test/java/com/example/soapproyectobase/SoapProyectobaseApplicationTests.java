package com.example.soapproyectobase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapProyectobaseApplicationTests {
    /*

    @Test
    void contextLoads() {
    }

     */

}
