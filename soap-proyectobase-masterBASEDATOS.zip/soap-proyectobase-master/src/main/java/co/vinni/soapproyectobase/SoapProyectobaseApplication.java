package co.vinni.soapproyectobase;

import co.vinni.soapproyectobase.controladores.ControladorVehiculo;
import co.vinni.soapproyectobase.entidades.Vehiculo;
import co.vinni.soapproyectobase.repositorios.RepositorioVehiculo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 * author Vinni 2023
 */
@SpringBootApplication
public class SoapProyectobaseApplication implements CommandLineRunner {

        @Autowired
        RepositorioVehiculo repositorioVehiculo;

        public static void main(String[] args) {

                SpringApplication.run(SoapProyectobaseApplication.class);
        }
        @Override
        public void run(String... args) throws Exception {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        Scanner datos = new Scanner (System.in);
        ControladorVehiculo cv = new ControladorVehiculo();
        Vehiculo vehiculo = new Vehiculo();
        Vehiculo vehiculo2 = new Vehiculo();
        Date fecha = new Date(124, 1, 27, 10, 30, 15);
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
       // vehiculo.setPais("Ecuador");
        //   vehiculo.setPrecio(70000);
        //  vehiculo.setTipo("camioneta");
      //  vehiculo.setMunicipio("Bogota");
       //vehiculo.setFechaAdquisicion(fecha);
       // vehiculo.setMarca("audi");
       // vehiculo.setDepartamento("Bogota");

        System.out.println("Bienvenido");

        System.out.println("Digite  el país:");
        vehiculo.setPais(datos.next());
       /* System.out.println("Digite  la placa");
        vehiculo.DsetPlaca(datos.next());*/
        System.out.println("Digite  el Departamento:");
        vehiculo.setDepartamento(datos.next());
        System.out.println("Digite  el Municipio:");
        vehiculo.setMunicipio(datos.next());
    /*   System.out.print("Ingrese la fecha de vencimiento del impuesto (YYYY-MM-DD):"+ "\n");
       String fecha1 = datos.nextLine();
       int tipo = 0;
       try {
               LocalDate fechaVencimieno = LocalDate.parse(fecha1, formatter);
               System.out.println("Fecha ingresada: " + fechaVencimieno);

               vehiculo.setFechaAdquisicion(fechaVencimieno);

       } catch (Exception e) {
               System.out.println("Formato de fecha inválido. Por favor ingrese la fecha en el formato YYYY-MM-DD.");
       }
       */
        System.out.println("Digite  precio comercial del vehiculo:");
        vehiculo.setPrecio(datos.nextLong());
        System.out.println("Digite  el tipo del vehiculo:");
        vehiculo.setTipo(datos.next());
        System.out.println("Digite  la marca del vehiculo:");
        vehiculo.setMarca(datos.next());


//        vehiculo2.setPais("Ecuador");
//        vehiculo2.setPrecio(70000);
//        vehiculo2.setTipo("Campero");
//        vehiculo2.setMunicipio("Quito");
//        vehiculo2.setFechaAdquisicion(fecha);
//        vehiculo2.setMarca("Toyota");
//        vehiculo2.setDepartamento("Sin muni");
        repositorioVehiculo.save(vehiculo);
//        boolean guardado2 = cv.registrarVehiculo(vehiculo2);
       System.out.println("guardado");
//        System.out.println(guardado2);

        List vehiculo1 = repositorioVehiculo.findAll();

       if (vehiculo1 != null) {
           System.out.println("Lista recuperada:");
          for (Object obj : vehiculo1) {
             System.out.println(obj);
           }
        }

        }
}
